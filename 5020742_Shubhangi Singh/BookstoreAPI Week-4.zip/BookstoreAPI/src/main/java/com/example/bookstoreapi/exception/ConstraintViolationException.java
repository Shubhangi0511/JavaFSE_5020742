package com.example.bookstoreapi.exception;

public class ConstraintViolationException extends Throwable {
}
