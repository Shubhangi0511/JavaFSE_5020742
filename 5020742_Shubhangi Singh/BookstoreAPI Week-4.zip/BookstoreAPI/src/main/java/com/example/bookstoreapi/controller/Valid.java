package com.example.bookstoreapi.controller;

public @interface Valid {
}
