package com.example.bookstoreapi.model;

public @interface Min {
}
