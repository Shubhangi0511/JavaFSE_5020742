package com.example.EmployeeManagementSystem.model;

public @interface Table {
    String name();
}
