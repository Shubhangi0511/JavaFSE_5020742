package com.example.EmployeeManagementSystem.config;

public class EntityManagerFactory {
}
