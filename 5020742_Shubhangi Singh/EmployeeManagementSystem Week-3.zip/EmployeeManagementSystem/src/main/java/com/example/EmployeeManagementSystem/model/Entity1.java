package com.example.EmployeeManagementSystem.model;

public @interface Entity1 {
}
