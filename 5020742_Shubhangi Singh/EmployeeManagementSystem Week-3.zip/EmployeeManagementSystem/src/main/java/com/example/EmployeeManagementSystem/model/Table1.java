package com.example.EmployeeManagementSystem.model;

public @interface Table1 {
    String name();
}
