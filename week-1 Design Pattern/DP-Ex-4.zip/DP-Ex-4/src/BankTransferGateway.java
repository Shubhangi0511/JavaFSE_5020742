public class BankTransferGateway {
    public void transferFunds(String paymentMethod, double amount) {
        System.out.println("Transferring funds with Bank Transfer: " + paymentMethod + ", Amount: " + amount);
    }
}