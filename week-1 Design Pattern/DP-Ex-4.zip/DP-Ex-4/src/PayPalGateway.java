public class PayPalGateway {
    public void payWithPayPal(String paymentMethod, double amount) {
        System.out.println("Processing payment with PayPal: " + paymentMethod + ", Amount: " + amount);
    }
}